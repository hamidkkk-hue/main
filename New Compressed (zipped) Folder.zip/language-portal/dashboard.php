<?php 
include 'db.php';

if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <style>
    body { font-family: Arial; padding: 20px; background-color: #f5f5f5; }
    .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 5px #ccc; max-width: 500px; margin: auto; }
    a { display: block; margin: 10px 0; text-decoration: none; color: #007BFF; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>

<div class="card">
  <h2>Welcome, <?= htmlspecialchars($user['name']) ?> (<?= $user['role'] ?>)</h2>

  <a href="courses.php">📚 View Courses</a>
  <a href="progress.php">📊 View My Progress</a>

  <?php if ($user['role'] === 'admin'): ?>
    <a href="admin_dashboard.php">🛠️ Go to Admin Panel</a>
  <?php endif; ?>

  <a href="logout.php" style="color: red;">🚪 Logout</a>
</div>

</body>
</html>
