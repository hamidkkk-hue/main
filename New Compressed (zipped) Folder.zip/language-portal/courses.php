<?php
include 'db.php';
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Available Courses</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }

    .container {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }

    .course-card {
      background: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .course-card h3 {
      font-size: 22px;
      color: #333;
    }

    .course-card p {
      font-size: 16px;
      line-height: 1.5;
      color: #555;
    }

    .course-card a {
      text-decoration: none;
      color: #007bff;
      font-size: 16px;
    }

    .course-card a:hover {
      text-decoration: underline;
    }

    .back-link {
      text-align: center;
      margin-top: 20px;
    }

    .back-link a {
      color: #007bff;
      text-decoration: none;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Available Language Courses</h2>

  <?php
  $result = $conn->query("SELECT * FROM courses");
  while ($course = $result->fetch_assoc()):
  ?>
    <div class="course-card">
      <h3><?= htmlspecialchars($course['title']) ?></h3>
      <p><?= nl2br(htmlspecialchars($course['description'])) ?></p>
      <a href="lessons.php?course_id=<?= $course['id'] ?>">View Lessons</a>
    </div>
  <?php endwhile; ?>

  <div class="back-link">
    <a href="dashboard.php">⬅ Back to Dashboard</a>
  </div>
</div>

</body>
</html>
