<?php
include 'db.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

// Handle deleting a course
if (isset($_GET['delete_course'])) {
  $course_id = $_GET['delete_course'];

  // Deleting progress associated with this course (before deleting lessons)
  $delete_progress_stmt = $conn->prepare("DELETE FROM progress WHERE lesson_id IN (SELECT id FROM lessons WHERE course_id = ?)");
  $delete_progress_stmt->bind_param("i", $course_id);
  $delete_progress_stmt->execute();

  // Deleting quizzes associated with this course (before deleting lessons)
  $delete_quizzes_stmt = $conn->prepare("DELETE FROM quizzes WHERE lesson_id IN (SELECT id FROM lessons WHERE course_id = ?)");
  $delete_quizzes_stmt->bind_param("i", $course_id);
  $delete_quizzes_stmt->execute();

  // Deleting lessons associated with this course
  $delete_lessons_stmt = $conn->prepare("DELETE FROM lessons WHERE course_id = ?");
  $delete_lessons_stmt->bind_param("i", $course_id);
  $delete_lessons_stmt->execute();

  // Now, delete the course
  $delete_stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
  $delete_stmt->bind_param("i", $course_id);

  if ($delete_stmt->execute()) {
    echo "<p style='color: red; text-align: center;'>Course and related lessons, quizzes, and progress deleted successfully!</p>";
  } else {
    echo "<p style='color: red; text-align: center;'>Failed to delete course. Error: " . $delete_stmt->error . "</p>";
  }
}

// Handle creating a new course
if (isset($_POST['create_course'])) {
  $title = $_POST['title'];
  $desc = $_POST['description'];
  $stmt = $conn->prepare("INSERT INTO courses (title, description) VALUES (?, ?)");
  $stmt->bind_param("ss", $title, $desc);
  $stmt->execute();
  echo "<p style='color: green; text-align: center;'>Course created successfully!</p>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }

    .container {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }

    h3 {
      color: #333;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
      margin-bottom: 30px;
    }

    input[type="text"],
    textarea {
      width: 100%;
      padding: 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    textarea {
      resize: vertical;
      height: 150px;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }

    .course-list {
      margin-top: 30px;
    }

    .course-item {
      padding: 15px;
      background-color: #f8f9fc;
      border-radius: 6px;
      margin-bottom: 10px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .course-item a {
      color: #007bff;
      text-decoration: none;
    }

    .course-item a:hover {
      text-decoration: underline;
    }

    .delete-button {
      background-color: #dc3545;
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 6px;
      cursor: pointer;
    }

    .delete-button:hover {
      background-color: #c82333;
    }

    .back-link {
      text-align: center;
      margin-top: 20px;
    }

    .back-link a {
      color: #007bff;
      text-decoration: none;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Admin Panel</h2>

  <h3>Create Course</h3>
  <form method="POST" action="admin_dashboard.php">
    <input type="text" name="title" placeholder="Course Title" required>
    <textarea name="description" placeholder="Course Description"></textarea>
    <button type="submit" name="create_course">Create Course</button>
  </form>

  <h3>All Courses</h3>
  <?php
  $result = $conn->query("SELECT * FROM courses");
  while ($row = $result->fetch_assoc()):
  ?>
    <div class="course-item">
      <strong><?= htmlspecialchars($row['title']) ?></strong>
      <p><?= nl2br(htmlspecialchars($row['description'])) ?></p>
      <a href="manage_lessons.php?course_id=<?= $row['id'] ?>">Manage Lessons</a> |
      <a href="create_quiz.php?course_id=<?= $row['id'] ?>">Create Quiz</a>
      <form method="GET" style="display:inline;">
        <button type="submit" class="delete-button" name="delete_course" value="<?= $row['id'] ?>">Delete Course</button>
      </form>
    </div>
  <?php endwhile; ?>

  <div class="back-link">
    <a href="dashboard.php">⬅ Back to Dashboard</a>
  </div>
</div>

</body>
</html>
